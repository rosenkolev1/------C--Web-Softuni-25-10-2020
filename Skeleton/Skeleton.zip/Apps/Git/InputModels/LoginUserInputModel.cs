﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Git.InputModels
{
    public class LoginUserInputModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
